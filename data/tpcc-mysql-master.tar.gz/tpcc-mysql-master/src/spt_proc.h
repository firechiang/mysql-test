int error(MYSQL *mysql, MYSQL_STMT *mysql_stmt);

#define  TIMESTAMP_LEN  80
#define  STRFTIME_FORMAT	"%Y-%m-%d %H:%M:%S"

